import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { StudentFormComponent } from './student-form/student-form.component';
import { StudentDataComponent } from './student-data/student-data.component';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from "@angular/router";
import { StudentDataService } from "./student-form/student-data.service"
import { RouteAuthService } from "./services/route.auth.service";
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatDialogModule, MatInputModule, MatSelectModule} from "@angular/material";
import { StudentDataEditComponent } from './student-data-edit/student-data-edit.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { MenuComponent } from './menu/menu.component';
import { StudentReportComponent } from './student-report/student-report.component';
import {MatTabsModule} from '@angular/material/tabs';
import { PageNotFoundComponent } from './page-not-found.component';
import { AuthGuard} from "./guards/auth-guard.service";
import {AgmCoreModule} from "@agm/core";
import {AgmSnazzyInfoWindowModule} from "@agm/snazzy-info-window";
import {HttpClientModule} from "@angular/common/http";
import { EventemitterComponent } from './eventemitter/eventemitter.component';
import { EmitChildComponent } from './eventemitter/emit-child/emit-child.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentFormComponent,
    StudentDataComponent,
    StudentDataEditComponent,
    MenuComponent,
    StudentReportComponent,
    PageNotFoundComponent,
    EventemitterComponent,
    EmitChildComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatDialogModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatCheckboxModule,
    MatTabsModule,
    HttpClientModule,
    MatSelectModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCSIFuXPQXel1splGkx5ElXoU1bL60Jn-I'
    }),
    AgmSnazzyInfoWindowModule
  ],
  providers: [StudentDataService, RouteAuthService, AuthGuard],
  bootstrap: [AppComponent],
  entryComponents: [
    StudentDataEditComponent]

})
export class AppModule { }

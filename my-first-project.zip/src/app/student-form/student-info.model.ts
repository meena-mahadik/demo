
export class StudentInfo {
  studentName: string;
  studentAge: number;
  studentID: number;
  studentGender: string;
  studentEmail: string;
}
